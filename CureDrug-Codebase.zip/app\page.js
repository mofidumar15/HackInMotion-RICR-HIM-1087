'use client';

// ==========================================
// DEVELOPER MODIFICATION ZONE
// CHOSEN THEME: Pitch-Black Dark Mode (#000000) with Emerald (#10B981), Ruby (#EF4444) & Amber (#F59E0B) Visual States
// WHAT TO CHANGE HERE:
//   1. PATIENT_PERSONAS: Quick clinical presets for 1-click judging demos (Cardiac, Diabetic, Polypharmacy).
//   2. PERSISTENCE_KEY: LocalStorage key for client-side zero-database synchronization.
//   3. Tab navigation and layout configuration.
// EXTENSION POINT:
//   - Add Doctor Mode EHR export (FHIR / HL7 JSON bundle).
//   - Hook in biometrics sync (Apple Health, Google Fit, Withings blood pressure monitors).
// ==========================================

import React, { useState, useEffect, useCallback } from 'react';
import {
  Shield,
  ShieldAlert,
  ShieldCheck,
  Activity,
  Pill,
  FileText,
  Sparkles,
  AlertTriangle,
  Moon,
  Sun,
  Globe,
  Printer,
  Trash2,
  RefreshCw,
  User,
  UserCheck,
  Stethoscope,
  ChevronRight,
  Zap,
  Info,
  Heart,
  Share2,
  ExternalLink
} from 'lucide-react';

import DrugSearch from '../components/DrugSearch';
import PrescriptionOCR from '../components/PrescriptionOCR';
import AdvancedChallenges from '../components/AdvancedChallenges';

// Clinical Sample Personas for Instant Hackathon Judging Demonstrations
const PATIENT_PERSONAS = [
  {
    id: 'persona_cardiac',
    name: 'Robert Martinez',
    age: 67,
    conditions: 'Atrial Fibrillation, Hypertension, Prior TIA',
    allergies: 'Penicillin, Sulfa',
    drugs: [
      { id: 'p_med_1', rxcui: '855332', name: 'Warfarin 5 MG Oral Tablet', dosage: '5mg Bedtime', frequency: 'Once daily', category: 'Anticoagulant' },
      { id: 'p_med_2', rxcui: '243670', name: 'Aspirin 81 MG Oral Tablet', dosage: '81mg Morning', frequency: 'Once daily', category: 'Antiplatelet' },
      { id: 'p_med_3', rxcui: '314076', name: 'Lisinopril 10 MG Oral Tablet', dosage: '10mg Morning', frequency: 'Once daily', category: 'ACE Inhibitor' }
    ]
  },
  {
    id: 'persona_metabolic',
    name: 'Eleanor Vance',
    age: 59,
    conditions: 'Type 2 Diabetes, Hyperlipidemia, GERD',
    allergies: 'None reported',
    drugs: [
      { id: 'p_med_4', rxcui: '860975', name: 'Metformin 500 MG Oral Tablet', dosage: '500mg Twice daily', frequency: 'Twice daily', category: 'Antidiabetic' },
      { id: 'p_med_5', rxcui: '312961', name: 'Simvastatin 20 MG Oral Tablet', dosage: '20mg Bedtime', frequency: 'Once daily', category: 'Statin' }
    ]
  },
  {
    id: 'persona_pain',
    name: 'David Chen',
    age: 45,
    conditions: 'Osteoarthritis, Chronic Low Back Pain',
    allergies: 'Codeine',
    drugs: [
      { id: 'p_med_6', rxcui: '197806', name: 'Ibuprofen 400 MG Oral Tablet', dosage: '400mg PRN', frequency: 'As needed', category: 'NSAID' },
      { id: 'p_med_7', rxcui: '855332', name: 'Warfarin 5 MG Oral Tablet', dosage: '5mg Evening', frequency: 'Once daily', category: 'Anticoagulant' }
    ]
  }
];

const PERSISTENCE_KEY = 'curedrug_active_regimen_v1';
const PERSISTENCE_PROFILE_KEY = 'curedrug_patient_profile_v1';

export default function Dashboard() {
  // Theme State
  const [isDarkMode, setIsDarkMode] = useState(true);

  // Active Navigation Tab
  const [activeTab, setActiveTab] = useState('interactions'); // 'interactions' | 'ocr' | 'advanced' | 'report'

  // Auth & Profile State
  const [userRole, setUserRole] = useState('Patient'); // 'Patient' | 'Doctor' | 'Guest'
  const [patientProfile, setPatientProfile] = useState({
    name: 'Robert Martinez',
    age: 67,
    conditions: 'Atrial Fibrillation, Hypertension',
    allergies: 'Penicillin, Sulfa'
  });
  const [showAuthModal, setShowAuthModal] = useState(false);

  // Active Patient Medication Regimen
  const [activeDrugs, setActiveDrugs] = useState([]);

  // Interaction Analysis State
  const [interactionResults, setInteractionResults] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Gemini AI Synthesis State
  const [aiSummary, setAiSummary] = useState('');
  const [aiLanguage, setAiLanguage] = useState('en');
  const [isAiSynthesizing, setIsAiSynthesizing] = useState(false);
  const [aiSource, setAiSource] = useState('Gemini 1.5');

  // Initialize theme and load persisted data
  useEffect(() => {
    // Theme toggle
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Load from LocalStorage on mount
  useEffect(() => {
    try {
      const savedDrugs = localStorage.getItem(PERSISTENCE_KEY);
      const savedProfile = localStorage.getItem(PERSISTENCE_PROFILE_KEY);

      if (savedDrugs) {
        setActiveDrugs(JSON.parse(savedDrugs));
      } else {
        // Pre-populate with Robert Martinez persona for instant judging
        setActiveDrugs(PATIENT_PERSONAS[0].drugs);
      }

      if (savedProfile) {
        setPatientProfile(JSON.parse(savedProfile));
      }
    } catch (e) {
      console.warn('LocalStorage load error:', e);
      setActiveDrugs(PATIENT_PERSONAS[0].drugs);
    }
  }, []);

  // Synchronize active drugs to LocalStorage
  const updateDrugsAndPersist = useCallback((newDrugs) => {
    setActiveDrugs(newDrugs);
    try {
      localStorage.setItem(PERSISTENCE_KEY, JSON.stringify(newDrugs));
    } catch (e) {
      console.warn('LocalStorage save error:', e);
    }
  }, []);

  // Handle Add Single Drug
  const handleAddDrug = (newDrug) => {
    const updated = [...activeDrugs, newDrug];
    updateDrugsAndPersist(updated);
  };

  // Handle Add Multiple Drugs from OCR
  const handleAddMultipleDrugs = (newMeds) => {
    const updated = [...activeDrugs, ...newMeds];
    updateDrugsAndPersist(updated);
    setActiveTab('interactions');
  };

  // Handle Remove Drug
  const handleRemoveDrug = (id) => {
    const updated = activeDrugs.filter((d) => d.id !== id);
    updateDrugsAndPersist(updated);
  };

  // Clear All Drugs
  const handleClearAll = () => {
    if (confirm('Clear all medications from current patient regimen?')) {
      updateDrugsAndPersist([]);
      setInteractionResults(null);
      setAiSummary('');
    }
  };

  // Load Persona
  const handleSelectPersona = (persona) => {
    setPatientProfile({
      name: persona.name,
      age: persona.age,
      conditions: persona.conditions,
      allergies: persona.allergies
    });
    updateDrugsAndPersist(persona.drugs);
  };

  // Run Interaction Analysis Pipeline
  const runInteractionCheck = useCallback(async () => {
    if (activeDrugs.length < 2) {
      setInteractionResults({
        totalInteractions: 0,
        overallRisk: 'Safe',
        highestScore: 0,
        interactions: [],
        message: 'Add at least 2 medications to run the interaction pipeline.'
      });
      return;
    }

    setIsAnalyzing(true);

    try {
      const rxcuis = activeDrugs.map((d) => d.rxcui).filter(Boolean);

      const res = await fetch('/api/check-interactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rxcuis, drugs: activeDrugs })
      });

      const data = await res.json();
      setInteractionResults(data);

      // Auto-trigger Gemini synthesis
      triggerGeminiSynthesis(data.interactions || [], aiLanguage);
    } catch (err) {
      console.error('Interaction analysis error:', err);
    } finally {
      setIsAnalyzing(false);
    }
  }, [activeDrugs, aiLanguage]);

  // Run interaction check whenever drug list changes
  useEffect(() => {
    if (activeDrugs.length >= 2) {
      runInteractionCheck();
    } else {
      setInteractionResults(null);
      setAiSummary('');
    }
  }, [activeDrugs.length, runInteractionCheck]);

  // Trigger Google Gemini AI Synthesis
  const triggerGeminiSynthesis = async (interactions, lang = 'en') => {
    setIsAiSynthesizing(true);
    try {
      const res = await fetch('/api/gemini-summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          interactions,
          activeDrugs,
          patientProfile,
          lang
        })
      });

      const data = await res.json();
      setAiSummary(data.summary || 'Summary unavailable.');
      setAiSource(data.isLiveGemini ? 'Google Gen AI (Gemini 1.5)' : 'CureDrug Clinical Synthesizer');
    } catch (err) {
      console.warn('Gemini summary error:', err);
      setAiSummary('Unable to complete AI synthesis. Please verify medical guidance with a healthcare provider.');
    } finally {
      setIsAiSynthesizing(false);
    }
  };

  // Handle language switch
  const handleLanguageChange = (newLang) => {
    setAiLanguage(newLang);
    if (interactionResults?.interactions) {
      triggerGeminiSynthesis(interactionResults.interactions, newLang);
    }
  };

  // Print clinical summary
  const handlePrint = () => {
    window.print();
  };

  // Determine overall status card styling
  const overallRisk = interactionResults?.overallRisk || (activeDrugs.length < 2 ? 'Safe' : 'Analyzing');
  const isSevere = overallRisk === 'Severe';
  const isModerate = overallRisk === 'Moderate';
  const isSafe = overallRisk === 'Safe' || activeDrugs.length < 2;

  return (
    <div className="min-h-screen bg-black text-slate-100 selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Global Navigation Bar */}
      <header className="sticky top-0 z-40 border-b border-slate-800/80 bg-black/85 backdrop-blur-xl no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Logo & Clinical Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-cyan-500 p-0.5 shadow-lg shadow-emerald-500/20">
              <div className="w-full h-full bg-black rounded-[10px] flex items-center justify-center">
                <ShieldCheck className="w-6 h-6 text-emerald-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-extrabold tracking-tight text-white flex items-center gap-1.5">
                  Cure<span className="text-emerald-400">Drug</span>
                </h1>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/30 tracking-wide uppercase">
                  NIH RxNorm AI
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Smart Medicine Safety & Drug Interaction Assistant
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-900/80 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveTab('interactions')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'interactions'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/60'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Activity className="w-4 h-4" />
              Interaction Engine
            </button>

            <button
              onClick={() => setActiveTab('ocr')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'ocr'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/60'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileText className="w-4 h-4" />
              Prescription OCR
            </button>

            <button
              onClick={() => setActiveTab('advanced')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'advanced'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/60'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              Compliance & AI Symptoms
            </button>
          </nav>

          {/* Right Action Tools: Role Switcher & Theme Toggle */}
          <div className="flex items-center gap-3">
            {/* Persona Switcher Dropdown */}
            <div className="hidden lg:flex items-center gap-2 bg-slate-900/90 border border-slate-800 rounded-xl px-2.5 py-1">
              <User className="w-3.5 h-3.5 text-emerald-400" />
              <select
                value={patientProfile.name}
                onChange={(e) => {
                  const selected = PATIENT_PERSONAS.find(p => p.name === e.target.value);
                  if (selected) handleSelectPersona(selected);
                }}
                className="bg-transparent text-xs text-slate-200 font-medium focus:outline-none cursor-pointer"
              >
                {PATIENT_PERSONAS.map(p => (
                  <option key={p.id} value={p.name} className="bg-slate-900 text-white">
                    {p.name} ({p.age}y - {p.drugs.length} Meds)
                  </option>
                ))}
              </select>
            </div>

            {/* Doctor / Patient Mode Badge */}
            <button
              onClick={() => setUserRole(userRole === 'Patient' ? 'Physician Mode' : 'Patient')}
              className={`text-xs px-2.5 py-1.5 rounded-xl font-bold border flex items-center gap-1.5 transition-all ${
                userRole === 'Physician Mode'
                  ? 'bg-cyan-950/80 border-cyan-500/50 text-cyan-300'
                  : 'bg-slate-900 border-slate-800 text-slate-300'
              }`}
              title="Toggle Clinical View Mode"
            >
              <Stethoscope className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">{userRole}</span>
            </button>

            {/* Theme Toggle */}
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white transition-colors"
              title="Toggle Theme"
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-cyan-400" />}
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Patient Health Context Card & Visual Severity Gauge */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left: Patient Profile Banner */}
          <div className="lg:col-span-8 glass-card p-5 border-slate-800 relative overflow-hidden flex flex-col justify-between">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center text-emerald-400 font-bold text-lg">
                  {patientProfile.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-white">{patientProfile.name}</h2>
                    <span className="text-[11px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                      Age: {patientProfile.age}
                    </span>
                    <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                      Active Profile
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 mt-1 flex flex-wrap items-center gap-x-3 gap-y-1">
                    <span><strong>Conditions:</strong> {patientProfile.conditions}</span>
                    <span>•</span>
                    <span><strong>Allergies:</strong> <span className="text-amber-400 font-medium">{patientProfile.allergies}</span></span>
                  </div>
                </div>
              </div>

              {/* Action Buttons: Print Report & Reset */}
              <div className="flex items-center gap-2 no-print">
                <button
                  type="button"
                  onClick={handlePrint}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs font-semibold text-slate-200 hover:text-white hover:bg-slate-800 flex items-center gap-1.5 transition-all shadow-sm"
                >
                  <Printer className="w-3.5 h-3.5 text-cyan-400" />
                  Print / PDF
                </button>

                <button
                  type="button"
                  onClick={handleClearAll}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-semibold text-slate-400 hover:text-red-400 hover:border-red-500/40 flex items-center gap-1.5 transition-all"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Clear All
                </button>
              </div>
            </div>

            {/* Quick Demo Persona Bar */}
            <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center gap-2 text-xs no-print">
              <span className="text-slate-400 font-medium flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-amber-400" /> Hackathon Demo Profiles:
              </span>
              {PATIENT_PERSONAS.map(persona => (
                <button
                  key={persona.id}
                  onClick={() => handleSelectPersona(persona)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-all ${
                    patientProfile.name === persona.name
                      ? 'bg-emerald-950 text-emerald-300 border-emerald-500/50'
                      : 'bg-slate-900/80 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                >
                  {persona.name} ({persona.drugs.length} Meds)
                </button>
              ))}
            </div>
          </div>

          {/* Right: Dynamic Visual Severity Status Card (Safe Emerald vs Dangerous Ruby) */}
          <div
            className={`lg:col-span-4 glass-card p-5 flex flex-col justify-between transition-all duration-500 ${
              isSevere
                ? 'status-danger bg-red-950/20'
                : isModerate
                ? 'status-warning bg-amber-950/20'
                : 'status-safe bg-emerald-950/20'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {isSevere ? (
                  <ShieldAlert className="w-6 h-6 text-red-500 animate-bounce" />
                ) : isModerate ? (
                  <AlertTriangle className="w-6 h-6 text-amber-500" />
                ) : (
                  <ShieldCheck className="w-6 h-6 text-emerald-400" />
                )}
                <span className="text-xs uppercase tracking-wider font-extrabold text-slate-300">
                  Interaction Risk Gauge
                </span>
              </div>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase font-mono ${
                  isSevere ? 'badge-ruby' : isModerate ? 'badge-amber' : 'badge-emerald'
                }`}
              >
                {overallRisk}
              </span>
            </div>

            <div className="my-3">
              <div className="flex items-baseline gap-2">
                <span
                  className={`text-4xl font-extrabold tracking-tight ${
                    isSevere ? 'text-red-400' : isModerate ? 'text-amber-400' : 'text-emerald-400'
                  }`}
                >
                  {interactionResults ? interactionResults.highestScore : 0}
                  <span className="text-lg text-slate-500 font-normal">/100</span>
                </span>
                <span className="text-xs text-slate-300 font-medium">
                  {isSevere
                    ? 'Critical Hazard Detected'
                    : isModerate
                    ? 'Moderate Conflict'
                    : 'Regimen Clear'}
                </span>
              </div>
              <div className="w-full bg-slate-800/80 rounded-full h-2 mt-2 overflow-hidden">
                <div
                  className={`h-2 rounded-full transition-all duration-700 ${
                    isSevere
                      ? 'bg-gradient-to-r from-red-600 to-rose-500'
                      : isModerate
                      ? 'bg-gradient-to-r from-amber-500 to-yellow-400'
                      : 'bg-gradient-to-r from-emerald-500 to-teal-400'
                  }`}
                  style={{ width: `${Math.max(8, interactionResults?.highestScore || 5)}%` }}
                />
              </div>
            </div>

            <div className="text-[11px] text-slate-400 flex items-center justify-between">
              <span>{activeDrugs.length} Meds Active</span>
              <span className="font-mono text-slate-300">
                {interactionResults ? `${interactionResults.totalInteractions} Interaction(s)` : '0 Interactions'}
              </span>
            </div>
          </div>
        </div>

        {/* Mobile Tab Switcher */}
        <div className="flex md:hidden items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800 overflow-x-auto no-print">
          <button
            onClick={() => setActiveTab('interactions')}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold whitespace-nowrap ${
              activeTab === 'interactions' ? 'bg-emerald-600 text-white' : 'text-slate-400'
            }`}
          >
            Interactions
          </button>
          <button
            onClick={() => setActiveTab('ocr')}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold whitespace-nowrap ${
              activeTab === 'ocr' ? 'bg-emerald-600 text-white' : 'text-slate-400'
            }`}
          >
            Prescription OCR
          </button>
          <button
            onClick={() => setActiveTab('advanced')}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold whitespace-nowrap ${
              activeTab === 'advanced' ? 'bg-emerald-600 text-white' : 'text-slate-400'
            }`}
          >
            Reminders & AI
          </button>
        </div>

        {/* ========================================== */}
        {/* VIEW 1: INTERACTION CHECKER DASHBOARD      */}
        {/* ========================================== */}
        {activeTab === 'interactions' && (
          <div className="space-y-6">
            {/* Top: RxNorm Autocomplete Search Box */}
            <div className="glass-card p-6 border-slate-800">
              <div className="mb-4">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Pill className="w-5 h-5 text-emerald-400" />
                  RxNorm Medicine Lookup & Smart Autocomplete
                </h3>
                <p className="text-xs text-slate-400">
                  Search NIH RxNorm database with real-time typo tolerance, RxCUI concept resolution, and clinical presets.
                </p>
              </div>

              <DrugSearch onAddDrug={handleAddDrug} activeDrugs={activeDrugs} />
            </div>

            {/* Active Regimen Grid & Conflict Results */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Column: Active Patient Drugs List (4 Cols) */}
              <div className="lg:col-span-4 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <Activity className="w-4 h-4 text-emerald-400" />
                    Active Patient Regimen ({activeDrugs.length})
                  </h4>
                  <span className="text-[10px] text-slate-500">LocalStorage Synced</span>
                </div>

                {activeDrugs.length === 0 ? (
                  <div className="p-8 text-center glass-card border-slate-800/80 rounded-2xl space-y-3">
                    <Pill className="w-10 h-10 text-slate-600 mx-auto" />
                    <p className="text-xs text-slate-400">No active medications loaded yet.</p>
                    <p className="text-[11px] text-slate-500">Search a medicine above or choose a demo persona.</p>
                  </div>
                ) : (
                  <div className="space-y-2.5 max-h-[520px] overflow-y-auto pr-1">
                    {activeDrugs.map((drug) => (
                      <div
                        key={drug.id || drug.rxcui}
                        className="p-3.5 bg-slate-900/90 hover:bg-slate-900 border border-slate-800 rounded-xl flex items-start justify-between gap-2 group transition-all"
                      >
                        <div className="space-y-1">
                          <h5 className="text-xs font-bold text-white group-hover:text-emerald-300">
                            {drug.name}
                          </h5>
                          <div className="flex flex-wrap items-center gap-1.5 text-[10px]">
                            <span className="font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 border border-slate-700">
                              RxCUI: {drug.rxcui}
                            </span>
                            <span className="px-1.5 py-0.2 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/40">
                              {drug.dosage || 'Standard Dose'}
                            </span>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleRemoveDrug(drug.id)}
                          className="p-1 text-slate-500 hover:text-red-400 transition-colors"
                          title="Remove medication"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Right Column: Interaction Conflicts & Gemini AI Summary (8 Cols) */}
              <div className="lg:col-span-8 space-y-6">
                {/* 1. Clinical Interaction Cards */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4 text-emerald-400" />
                      Algorithmic Interaction Report
                      {isAnalyzing && <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-400" />}
                    </h4>
                    <span className="text-[11px] text-slate-400 font-mono">
                      Engine: {interactionResults?.isLiveNIH ? 'NIH RxNav Live' : 'Clinical Rules Matrix'}
                    </span>
                  </div>

                  {activeDrugs.length < 2 ? (
                    <div className="p-8 text-center glass-card border-slate-800 rounded-2xl">
                      <Info className="w-8 h-8 text-slate-500 mx-auto mb-2" />
                      <h5 className="text-sm font-bold text-white">Minimum 2 Drugs Required</h5>
                      <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                        Add two or more medications to initiate pairwise interaction scanning and clinical mechanism evaluation.
                      </p>
                    </div>
                  ) : interactionResults?.interactions?.length === 0 ? (
                    <div className="p-6 rounded-2xl bg-emerald-950/20 border border-emerald-500/40 text-center space-y-2">
                      <ShieldCheck className="w-8 h-8 text-emerald-400 mx-auto" />
                      <h5 className="text-sm font-bold text-white">No Severe Drug Interactions Identified</h5>
                      <p className="text-xs text-slate-300 max-w-md mx-auto">
                        NIH RxNorm and clinical databases show safe pharmacological compatibility for this combination.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {interactionResults?.interactions?.map((int) => (
                        <div
                          key={int.id}
                          className={`p-4 rounded-2xl glass-card transition-all ${
                            int.severity === 'Severe'
                              ? 'status-danger bg-red-950/30'
                              : int.severity === 'Moderate'
                              ? 'status-warning bg-amber-950/30'
                              : 'border-slate-800 bg-slate-900/60'
                          }`}
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-2.5">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-extrabold text-white">
                                {int.drugA.name} <span className="text-slate-400">×</span> {int.drugB.name}
                              </span>
                            </div>
                            <span
                              className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded font-mono ${
                                int.severity === 'Severe'
                                  ? 'badge-ruby'
                                  : int.severity === 'Moderate'
                                  ? 'badge-amber'
                                  : 'badge-emerald'
                              }`}
                            >
                              {int.severity} (Score: {int.riskScore}/100)
                            </span>
                          </div>

                          <div className="mt-3 space-y-2 text-xs">
                            <p className="text-slate-200 leading-relaxed">
                              {int.description}
                            </p>

                            {int.mechanism && (
                              <div className="text-[11px] text-slate-400 bg-black/40 p-2.5 rounded-lg border border-white/5">
                                <strong className="text-slate-300">Mechanism:</strong> {int.mechanism}
                              </div>
                            )}

                            {int.action && (
                              <div className="text-[11px] text-emerald-300 bg-emerald-950/50 p-2.5 rounded-lg border border-emerald-500/30">
                                <strong>Clinical Action:</strong> {int.action}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* 2. Google Gemini Multilingual Synthesis AI Card */}
                <div className="glass-card p-5 border-slate-800 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-lg bg-gradient-to-tr from-emerald-500 to-cyan-500 text-black">
                        <Sparkles className="w-4 h-4 font-bold" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white flex items-center gap-2">
                          Gemini Health Companion Summary
                          {isAiSynthesizing && <RefreshCw className="w-3 h-3 animate-spin text-emerald-400" />}
                        </h4>
                        <p className="text-[11px] text-slate-400">
                          Non-technical actionable synthesis for patients & caregivers.
                        </p>
                      </div>
                    </div>

                    {/* Multilingual Selector */}
                    <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1 text-xs">
                      <Globe className="w-3.5 h-3.5 text-cyan-400" />
                      <select
                        value={aiLanguage}
                        onChange={(e) => handleLanguageChange(e.target.value)}
                        className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer text-xs"
                      >
                        <option value="en" className="bg-slate-900">English (EN)</option>
                        <option value="hi" className="bg-slate-900">हिंदी (Hindi)</option>
                        <option value="es" className="bg-slate-900">Español (ES)</option>
                        <option value="fr" className="bg-slate-900">Français (FR)</option>
                        <option value="de" className="bg-slate-900">Deutsch (DE)</option>
                        <option value="zh" className="bg-slate-900">中文 (Chinese)</option>
                        <option value="ar" className="bg-slate-900">العربية (Arabic)</option>
                      </select>
                    </div>
                  </div>

                  {isAiSynthesizing ? (
                    <div className="p-8 text-center space-y-2">
                      <RefreshCw className="w-6 h-6 animate-spin text-emerald-400 mx-auto" />
                      <p className="text-xs text-slate-300">Synthesizing clinical advice in {aiLanguage.toUpperCase()}...</p>
                    </div>
                  ) : aiSummary ? (
                    <div className="p-4 bg-slate-950/80 rounded-xl border border-slate-800 text-xs text-slate-200 leading-relaxed whitespace-pre-wrap space-y-2">
                      {aiSummary}
                    </div>
                  ) : (
                    <div className="p-4 text-center text-xs text-slate-500">
                      Add medications to generate AI safety guidelines.
                    </div>
                  )}

                  <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1">
                    <span>Source: {aiSource}</span>
                    <span>Powered by Google Gen AI SDK</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================== */}
        {/* VIEW 2: PRESCRIPTION OCR SCANNER           */}
        {/* ========================================== */}
        {activeTab === 'ocr' && (
          <PrescriptionOCR
            onAddMultipleDrugs={handleAddMultipleDrugs}
            activeDrugs={activeDrugs}
          />
        )}

        {/* ========================================== */}
        {/* VIEW 3: ADVANCED CHALLENGES (REMINDERS & AI) */}
        {/* ========================================== */}
        {activeTab === 'advanced' && (
          <AdvancedChallenges
            activeDrugs={activeDrugs}
            patientProfile={patientProfile}
            onAddDrug={handleAddDrug}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="mt-12 border-t border-slate-900 bg-black/90 py-6 text-center text-xs text-slate-500 no-print">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© 2026 CureDrug. Built with Google Antigravity & NIH RxNorm for HealthTech Hackathon.</p>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Client-Side Tesseract OCR</span>
            <span>•</span>
            <span>Gemini AI Multilingual</span>
            <span>•</span>
            <span>Zero-DB IndexedDB Storage</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
