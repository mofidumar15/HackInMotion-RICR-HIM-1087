// ==========================================
// DEVELOPER MODIFICATION ZONE
// CHOSEN THEME: Pitch-Black Dark Mode (#000000) by default
// WHAT TO CHANGE HERE:
//   1. Adjust <title> and meta descriptions for SEO or hackathon branding.
//   2. Modify default HTML lang attribute or import additional Google Fonts.
// EXTENSION POINT:
//   - Inject global analytics, Sentry error logging, or EHR iframe bridge providers.
//   - Add HIPAA/GDPR compliance disclaimer banners across global views.
// ==========================================

import './globals.css'

export const metadata = {
  title: 'CureDrug | Smart Medicine Safety & Drug Interaction Assistant',
  description: 'AI-Powered Drug Interaction Checker, Prescription OCR, NIH RxNorm Safety Scanner, and Multilingual Health Companion.',
  keywords: ['drug interactions', 'rxnorm', 'medicine safety', 'prescription OCR', 'gemini health ai', 'healthtech'],
  authors: [{ name: 'CureDrug HealthTech Team' }],
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
        {/* Tesseract.js client CDN pre-connect for zero-download OCR */}
        <link rel="preconnect" href="https://unpkg.com" />
      </head>
      <body className="min-h-screen bg-black text-slate-100 antialiased selection:bg-emerald-500/30 selection:text-emerald-200">
        <div className="relative min-h-screen flex flex-col justify-between overflow-x-hidden bg-[#000000] bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(16,185,129,0.12),rgba(255,255,255,0))]">
          {children}
        </div>
      </body>
    </html>
  )
}
