// ==========================================
// DEVELOPER MODIFICATION ZONE
// CHOSEN THEME: Pitch-Black Dark Mode (#000000) & High-Contrast Light Mode
// WHAT TO CHANGE HERE: Adjust theme color tokens, glowing box-shadow radii, and glassmorphic blur levels.
// EXTENSION POINT: Add hospital-specific color themes (e.g., Mayo Clinic Blue, Cleveland Clinic Green) or accessible high-contrast modes.
// ==========================================

/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        background: '#000000',
        surface: {
          900: '#05070B',
          800: '#0B0F17',
          700: '#111827',
          600: '#1F2937',
        },
        emerald: {
          500: '#10B981',
          400: '#34D399',
        },
        ruby: {
          500: '#EF4444',
          400: '#F87171',
          600: '#DC2626',
        },
        amber: {
          500: '#F59E0B',
          400: '#FBBF24',
        },
        cyan: {
          500: '#06B6D4',
          400: '#22D3EE',
        }
      },
      boxShadow: {
        'glow-emerald': '0 0 25px -3px rgba(16, 185, 129, 0.45), 0 0 10px -2px rgba(16, 185, 129, 0.3)',
        'glow-ruby': '0 0 30px -2px rgba(239, 68, 68, 0.6), 0 0 12px -2px rgba(239, 68, 68, 0.4)',
        'glow-amber': '0 0 25px -3px rgba(245, 158, 11, 0.45), 0 0 10px -2px rgba(245, 158, 11, 0.3)',
        'glow-cyan': '0 0 25px -3px rgba(6, 182, 212, 0.4), 0 0 10px -2px rgba(6, 182, 212, 0.25)',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'glow-pulse': 'glowPulse 2s ease-in-out infinite alternate',
      },
      keyframes: {
        glowPulse: {
          '0%': { boxShadow: '0 0 15px rgba(239, 68, 68, 0.4)' },
          '100%': { boxShadow: '0 0 35px rgba(239, 68, 68, 0.8)' },
        }
      }
    },
  },
  plugins: [],
}
