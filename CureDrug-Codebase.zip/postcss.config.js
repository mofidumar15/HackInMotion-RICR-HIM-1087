// ==========================================
// DEVELOPER MODIFICATION ZONE
// CHOSEN THEME: Pitch-Black Dark Mode (#000000)
// WHAT TO CHANGE HERE: PostCSS plugins configuration.
// EXTENSION POINT: Add custom CSS preprocessing plugins or CSS nano optimizations.
// ==========================================

module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
